<?php
class AppController extends Controller {
    var $helpers = array('Form','Html','Javascript','Session','Ajax','Lightbox');
}
?>
