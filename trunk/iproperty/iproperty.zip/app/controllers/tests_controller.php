<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class TestsController extends AppController{
    //var $uses = 'Directorys';
    var $uses = '';
    function index(){

    }
    function service(){

    }

    function directory(){
        
    }
     function gallery(){

    }
    function contact(){

    }
   function aboutUs(){

   }
   function images(){
       
   }
}
?>
